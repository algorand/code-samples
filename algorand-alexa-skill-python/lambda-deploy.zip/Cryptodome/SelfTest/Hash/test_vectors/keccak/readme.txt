Files downloaded on 22 October 2015 from http://keccak.noekeon.org/KeccakKAT-3.zip
